<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class UserSeeder extends Seeder
{
    public function run()
    {
        $data = [
            [
                'nama_pengguna' => 'shafira',
                'email' => 'shafira.amalina.krw@horizon.ac.id',
                'password' => password_hash('shafira', PASSWORD_BCRYPT),
            ],
            [
                'nama_pengguna' => 'admin',
                'password' => password_hash('admin123', PASSWORD_BCRYPT),
            ]
        ];

        $this->db->table('user')->insertBatch($data);
    }
}
