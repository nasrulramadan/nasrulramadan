<?php

namespace App\Controllers;

class Auth extends BaseController
{
    public function index()
    {
        return redirect()->to(site_url('login'));
    }

    public function login()
    {
        if (session('id_pengguna')) {
            return redirect()->to(site_url('home'));
        }
        return view('auth/login');
    }

    public function loginProccess()
    {
        $post = $this->request->getPost();
        $query = $this->db->table('user')->getWhere(['nama_pengguna' => $post['nama_pengguna']]);
        $user = $query->getRow();
        if ($user) {
            if (password_verify($post['password'], $user->password)) {
                $params = ['id_pengguna' => $user->id_pengguna];
                session()->set($params);
                return redirect()->to(site_url('home'));
            } else {
                return redirect()->back()->with('error', 'Password tidak sesuai');
            }
        } else {
            return redirect()->back()->with('error', 'Nama Pengguna tidak ditemukan');
        }
    }

    public function logout()
    {
        session()->remove('id_pengguna');
        return redirect()->to(site_url('login'));
    }
}
