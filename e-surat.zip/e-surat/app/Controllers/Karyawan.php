<?php

namespace App\Controllers;

use App\Models\Modelkaryawan;
use CodeIgniter\RESTful\ResourcePresenter;

class Karyawan extends ResourcePresenter
{
    protected $helpers = ['custom'];


    protected $karyawan;
    public function __construct()
    {
        $this->karyawan = new Modelkaryawan();
    }

    // protected $modelname = 'App\Models\Modelkaryawan';
    /**
     * Present a view of resource objects
     *
     * @return mixed
     */
    public function index()
    {
        // $data['karyawan'] = $this->karyawan->findAll();
        $data['karyawan'] = $this->karyawan->findAll();
        return view('karyawan/index', $data);
    }

    /**
     * Present a view to present a specific resource object
     *
     * @param mixed $id
     *
     * @return mixed
     */
    public function show($id = null)
    {
        //
    }

    /**
     * Present a view to present a new single resource object
     *
     * @return mixed
     */
    public function new()
    {
        return view('karyawan/new');
    }

    /**
     * Process the creation/insertion of a new resource object.
     * This should be a POST.
     *
     * @return mixed
     */
    public function create()
    {
        $data = $this->request->getPost();
        $this->karyawan->insert($data);
        return redirect()->to(site_url('karyawan'))->with('success', 'Data berhasil Ditambahkan.');
    }

    /**
     * Present a view to edit the properties of a specific resource object
     *
     * @param mixed $id
     *
     * @return mixed
     */
    public function edit($id = null)
    {
        $karyawan = $this->karyawan->where('id', $id)->first();
        if (is_object($karyawan)) {
            $data['karyawan'] = $karyawan;
            return view('karyawan/edit', $data);
        } else {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }
    }

    /**
     * Process the updating, full or partial, of a specific resource object.
     * This should be a POST.
     *
     * @param mixed $id
     *
     * @return mixed
     */
    public function update($id = null)
    {
        $data = $this->request->getPost();
        $this->karyawan->update($id, $data);
        return redirect()->to(site_url('karyawan'))->with('success', 'Data berhasil Diubah.');
    }

    /**
     * Present a view to confirm the deletion of a specific resource object
     *
     * @param mixed $id
     *
     * @return mixed
     */
    public function remove($id = null)
    {
        //
    }

    /**
     * Process the deletion of a specific resource object
     *
     * @param mixed $id
     *
     * @return mixed
     */
    public function delete($id = null)
    {
        // $this->karyawan->delete($id);
        $this->karyawan->where('id', $id)->delete();
        return redirect()->to(site_url('karyawan'))->with('success', 'Data berhasil Dihapus.');
    }
}
