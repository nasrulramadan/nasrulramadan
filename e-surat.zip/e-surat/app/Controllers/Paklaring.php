<?php

namespace App\Controllers;

use CodeIgniter\RESTful\ResourceController;
use App\Models\Modelkaryawan;
use App\Models\Modelpaklaring;

class Paklaring extends ResourceController
{
    protected $helpers = ['custom'];

    protected $karyawan;
    protected $paklaring;
    public function __construct()
    {
        $this->karyawan = new Modelkaryawan();
        $this->paklaring = new Modelpaklaring();
    }

    // protected $modelname = 'App\Models\Modelsurattugas';

    /**
     * Present a view of resource objects
     *
     * @return mixed
     */
    public function index()
    {
        $data['surat_ket_kerja'] = $this->paklaring->findAll();
        return view('paklaring/index', $data);
    }

    public function new()
    {
        $data['karyawan'] = $this->karyawan->findAll();
        return view('paklaring/new', $data);
    }

    /**
     * Process the creation/insertion of a new resource object.
     * This should be a POST.
     *
     * @return mixed
     */
    public function create()
    {
        $data = $this->request->getPost();
        $this->paklaring->insert($data);
        return redirect()->to(site_url('paklaring'))->with('success', 'Data berhasil Ditambahkan.');
    }

    /**
     * Present a view to edit the properties of a specific resource object
     *
     * @param mixed $id
     *
     * @return mixed
     */
    public function edit($id_skk = null)
    {
        $paklaring = $this->paklaring->where('id_skk', $id_skk)->first();
        if (is_object($paklaring)) {
            $data['paklaring'] = $paklaring;
            return view('paklaring/edit', $data);
        } else {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }
    }

    /**
     * Process the updating, full or partial, of a specific resource object.
     * This should be a POST.
     *
     * @param mixed $id
     *
     * @return mixed
     */
    public function update($id_skk = null)
    {
        $data = $this->request->getPost();
        $this->paklaring->update($id_skk, $data);
        return redirect()->to(site_url('paklaring'))->with('success', 'Data berhasil Diubah.');
    }

    /**
     * Present a view to confirm the deletion of a specific resource object
     *
     * @param mixed $id
     *
     * @return mixed
     */
    public function remove($id = null)
    {
        //
    }

    /**
     * Process the deletion of a specific resource object
     *
     * @param mixed $id
     *
     * @return mixed
     */
    public function delete($id_skk = null)
    {
        $this->paklaring->delete($id_skk);
        // $this->karyawan->where('id_karyawan', $id_karyawan)->delete();
        return redirect()->to(site_url('paklaring'))->with('success', 'Data berhasil Dihapus.');
    }
}
