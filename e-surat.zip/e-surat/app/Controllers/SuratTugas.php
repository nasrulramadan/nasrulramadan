<?php

namespace App\Controllers;

use CodeIgniter\RESTful\ResourceController;
use App\Models\Modelkaryawan;
use App\Models\Modelsurattugas;

class SuratTugas extends ResourceController
{
    protected $helpers = ['custom'];

    protected $karyawan;
    protected $surattugas;
    public function __construct()
    {
        $this->karyawan = new Modelkaryawan();
        $this->surattugas = new Modelsurattugas();
    }

    public function index()
    {
        $data['surat_tugas'] = $this->surattugas->findAll();
        return view('surattugas/index', $data);
    }

    public function new()
    {
        $data['karyawan'] = $this->karyawan->findAll();
        return view('surattugas/new', $data);
    }

    public function create()
    {
        $data = $this->request->getPost();
        $this->surattugas->insert($data);
        return redirect()->to(site_url('surattugas'))->with('success', 'Data berhasil Ditambahkan.');
    }

    public function edit($id_surat = null)
    {
        $surattugas = $this->surattugas->where('id_surat', $id_surat)->first();
        if (is_object($surattugas)) {
            $data['surat_tugas'] = $surattugas;
            return view('surattugas/edit', $data);
        } else {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }
    }

    /**
     * Process the updating, full or partial, of a specific resource object.
     * This should be a POST.
     *
     * @param mixed $id
     *
     * @return mixed
     */
    public function update($id_surat = null)
    {
        $data = $this->request->getPost();
        $this->surattugas->update($id_surat, $data);
        return redirect()->to(site_url('surattugas'))->with('success', 'Data berhasil Diubah.');
    }

    /**
     * Present a view to confirm the deletion of a specific resource object
     *
     * @param mixed $id
     *
     * @return mixed
     */
    public function remove($id = null)
    {
        //
    }

    /**
     * Process the deletion of a specific resource object
     *
     * @param mixed $id
     *
     * @return mixed
     */
    public function delete($id_surat = null)
    {
        $this->surattugas->delete($id_surat);
        // $this->karyawan->where('id_karyawan', $id_karyawan)->delete();
        return redirect()->to(site_url('surattugas'))->with('success', 'Data berhasil Dihapus.');
    }
}
