<?= $this->extend('layout/default') ?>
<?= $this->section('content') ?>

<title>Halaman | Form Surat Keterangan Kerja</title>

<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <div class="row d-flex justify-content-center">
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Form Surat Keterangan Kerja</h6>
            </div>
            <div class="card-body row">
                <div class="text-center">
                    <img class="img-fluid px-3 px-sm-8 mt-3 mb-4" style="width: 25rem;" src="<?= base_url('') ?>/assets/img/undraw_newsletter_re_wrob.svg" alt="...">
                </div>
                <form action="<?= site_url('paklaring'); ?>" method="post" autocomplete="off">
                    <?= csrf_field() ?>
                    <div class=" form-group row">
                        <label for="no_surat" class="col-sm-4 col-form-label">Nomor Surat</label>
                        <div class="col-sm-8">
                            <input type="text" class="form-control" name="no_surat" id="no_surat" placeholder="" autofocus required>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="nama" class="col-sm-4 col-form-label">Nama</label>
                        <div class="col-sm-8">
                            <select name="" id="" class="form-control">
                                <option value="">Pilih...</option>
                                <?php foreach ($karyawan as $key => $value) : ?>
                                    <option value="<?= $value->id ?>"><?= $value->nama ?></option>
                                <?php endforeach; ?>
                            </select>
                            <!-- <input type="text" class="form-control" name="nama" id="nama" required> -->
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="tgl_kegiatan" class="col-sm-4 col-form-label">Dari Tanggal</label>
                        <div class="col-sm-8">
                            <input type="date" class="form-control" name="tgl_kegiatan" id="tgl_kegiatan" required>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="tgl_kegiatan" class="col-sm-4 col-form-label">Sampai Tanggal</label>
                        <div class="col-sm-8">
                            <input type="date" class="form-control" name="tgl_kegiatan" id="tgl_kegiatan" required>
                        </div>
                    </div>

                    <div class="form-group">
                        <button type="button" class="btn btn-secondary nunito;">
                            <i class="fas fa-chevron-circle-left">
                                <a href="<?= site_url('paklaring') ?>" style="font-family: nunito; text-decoration:none; color:white; "> Kembali </a></i>
                        </button>
                        <button type="reset" class="btn btn-danger ml-5">
                            <i class="fas fa-trash lg"> Hapus</a></i>
                        </button>
                        <button type="submit" class="btn btn-success nunito;">
                            <i class="fas fa-paper-plane">
                                <a href="<?= site_url('paklaring') ?>" style="font-family: nunito; text-decoration:none; color:white; "> Simpan</a></i>
                        </button>
                    </div>
                </form>
            </div>
        </div>
        <!-- </div> -->

    </div>
    <!-- /.container-fluid -->
    <?= $this->endSection() ?>