<?= $this->extend('layout/default') ?>
<?= $this->section('content') ?>

<title>Data Surat Keterangan Kerja</title>

<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <!-- DataTales -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <div class="d-flex bd-highlight mb-0">
                <div class="mr-auto p-2 bd-highlight">
                    <h4 class="m-0 font-weight-bold text-primary "> Data Surat Keterangan Kerja</h4>
                </div>

                <div class="p-2 bd-highlight">
                    <a href="<?= site_url('paklaring/new') ?>" class="btn btn-outline-primary"><i class="fas fa-envelope"><b> + </b></a></i>
                </div>
            </div>
        </div>

        <?php if (session()->getFlashdata('success')) : ?>
            <div class="alert alert-success" role="alert">
                <button class="close" data-dismiss="alert">x</button>
                <b>Berhasil !</b>
                <?= session()->getFlashdata('success') ?>
            </div>
        <?php endif; ?>
        <?php if (session()->getFlashdata('error')) : ?>
            <div class="alert alert-danger" role="alert">
                <button class="close" data-dismiss="alert">x</button>
                <b>Berhasil !</b>
                <?= session()->getFlashdata('error') ?>
            </div>
        <?php endif; ?>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="50px">
                    <thead class="text-center">
                        <tr class="bg-gradient-primary m-0 font-weight-bold text-white">
                            <th>No.</th>
                            <th>Nomor Surat</th>
                            <th>Nama</th>
                            <th>Dari tanggal</th>
                            <th>Sampai Tanggal</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($surat_ket_kerja as $key => $value) : ?>
                            <tr>
                                <td><?= $key + 1 ?></td>
                                <td><?= $value->no_surat ?></td>
                                <td><?= $value->nama ?></td>
                                <td><?= $value->dari_tgl ?></td>
                                <td><?= $value->sampai_tgl ?></td>
                                <td class="text-center">
                                    <button class="btn btn-primary btn-sm d-inline" name="print"> <i class=" fas fa-print"></i></button>
                                    <a href="<?= site_url('paklaring/edit/' . $value->id_skk) ?>" class="btn btn-warning btn-sm"> <i class=" fas fa-pen"></i></a>
                                    <form action="<?= site_url('paklaring/delete/' . $value->id_skk) ?>" method="post" class="d-inline" onsubmit="return confirm('Yakin Mau dihapus ?')">
                                        <?= csrf_field() ?>
                                        <button class="btn btn-danger btn-sm"><i class="fas fa-trash"></i></button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<!-- /.container-fluid -->
<?= $this->endSection() ?>