<?= $this->extend('layout/default') ?>

<?= $this->section('title') ?>
<title>Halaman | Form Ubah Data Karyawan</title>
<?= $this->endSection() ?>

<?= $this->section('content') ?>
<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <div class="row d-flex justify-content-center">
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Form Ubah Data Karyawan</h6>
            </div>
            <div class="card-body row">
                <div class="text-center">
                    <img class="img-fluid px-3 px-sm-8 mt-5" style="width: 25rem;" src="<?= base_url('') ?>/assets/img/undraw_new_entries_re_cffr.svg" alt="...">
                </div>
                <form action="<?= site_url('karyawan/update/' . $karyawan->id); ?>" method="post" autocomplete="off">
                    <?= csrf_field() ?>
                    <input type="hidden" name="_method" value="PUT">
                    <div class=" form-group row">
                        <label for="id_karyawan" class="col-sm-4 col-form-label">Id Karyawan</label>
                        <div class="col-sm-8">
                            <input type="text" class="form-control" name="id_karyawan" id="id_karyawan" value="<?= $karyawan->id ?>" placeholder="KRW-2020-0073">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="nama" class="col-sm-4 col-form-label">Nama Lengkap</label>
                        <div class="col-sm-8">
                            <input type="text" class="form-control" name="nama" id="nama" value="<?= $karyawan->nama ?>">
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="jabatan" class="col-sm-4 col-form-label">Jabatan</label>
                        <div class="col-sm-8">
                            <input type="text" class="form-control" name="jabatan" id="jabatan" value="<?= $karyawan->jabatan ?>">
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="tgl_gabung" class="col-sm-4 col-form-label">Tanggal Gabung</label>
                        <div class="col-sm-8">
                            <input type="date" class="form-control" name="tgl_gabung" id="tgl_gabung" value="<?= $karyawan->tgl_gabung ?>">
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="tgl_lahir" class="col-sm-4 col-form-label">Tanggal Lahir</label>
                        <div class="col-sm-8">
                            <input type="date" class="form-control" name="tgl_lahir" id="tgl_lahir" value="<?= $karyawan->tgl_lahir ?>">
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="nomor_hp" class="col-sm-4 col-form-label">Nomor Telepon</label>
                        <div class="col-sm-8">
                            <input type="text" class="form-control" name="nomor_hp" id="nomor_hp" value="<?= $karyawan->nomor_hp ?>">
                        </div>
                    </div>

                    <div class="form-group">
                        <button type="button" class="btn btn-secondary nunito;">
                            <i class="fas fa-chevron-circle-left">
                                <a href="<?= site_url('karyawan') ?>" style="font-family: nunito; text-decoration:none; color:white; "> Kembali </a></i>
                        </button>
                        <button type="reset" class="btn btn-danger ml-5 nunito;">
                            <i class="fas fa-trash lg"> Batal</a></i>
                        </button>
                        <button type="submit" class="btn btn-success nunito;">
                            <i class="fas fa-paper-plane">
                                <a href="<?= site_url('karyawan') ?>" style="font-family: nunito; text-decoration:none; color:white; "> Simpan</a></i>
                        </button>
                        <!-- <button type="submit" class="btn btn-success nunito;">
                            <i class="fas fa-paper-plane"> Simpan</i>
                        </button> -->
                    </div>
                </form>
            </div>
        </div>
        <!-- </div> -->

    </div>
    <!-- /.container-fluid -->
    <?= $this->endSection() ?>