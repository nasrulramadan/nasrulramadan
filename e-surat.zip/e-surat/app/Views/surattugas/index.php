<?= $this->extend('layout/default') ?>
<?= $this->section('content') ?>

<title>Data Surat Tugas</title>

<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <!-- DataTales -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <div class="d-flex bd-highlight mb-0">
                <div class="mr-auto p-2 bd-highlight">
                    <h4 class="m-0 font-weight-bold text-primary "> Data Surat Tugas</h4>
                </div>

                <div class="p-2 bd-highlight">
                    <a href="<?= site_url('surattugas/new') ?>" class="btn btn-outline-primary"><i class="fas fa-envelope"> + </a></i>
                </div>
            </div>
        </div>

        <?php if (session()->getFlashdata('success')) : ?>
            <div class="alert alert-success" role="alert">
                <button class="close" data-dismiss="alert">x</button>
                <b>Berhasil !</b>
                <?= session()->getFlashdata('success') ?>
            </div>
        <?php endif; ?>
        <?php if (session()->getFlashdata('error')) : ?>
            <div class="alert alert-danger" role="alert">
                <button class="close" data-dismiss="alert">x</button>
                <b>Berhasil !</b>
                <?= session()->getFlashdata('error') ?>
            </div>
        <?php endif; ?>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="50px">
                    <thead class="text-center">
                        <tr class="bg-gradient-primary m-0 font-weight-bold text-white">
                            <th>No.</th>
                            <th>Nomor Surat</th>
                            <th>Nama</th>
                            <th>Kegiatan</th>
                            <th>Diselenggarakan_oleh</th>
                            <th>Tanggal Kegiatan</th>
                            <th>Lokasi</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($surat_tugas as $key => $value) : ?>
                            <tr>
                                <td><?= $key + 1 ?></td>
                                <td><?= $value->no_surat ?></td>
                                <td><?= $value->nama ?></td>
                                <td><?= $value->kegiatan ?></td>
                                <td><?= $value->diselenggarakan_oleh ?></td>
                                <td><?= $value->tgl_kegiatan ?></td>
                                <td><?= $value->lokasi ?></td>
                                <td class="text-center">
                                    <a href="#" class="btn btn-primary btn-sm d-inline"> <i class=" fas fa-print"></i></a>
                                    <a href="<?= site_url('surattugas/edit/' . $value->id_surat) ?>" class="btn btn-success btn-sm"> <i class=" fas fa-pen"></i></a>
                                    <form action="<?= site_url('surattugas/delete/' . $value->id_surat) ?>" method="post" class="d-inline" onsubmit="return confirm('Yakin Mau dihapus ?')">
                                        <?= csrf_field() ?>
                                        <button class="btn btn-warning btn-sm"><i class="fas fa-trash"></i></button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<script>
    $(document).ready(function() {
        $('.data').DataTable();
    });
</script>
<!-- /.container-fluid -->
<?= $this->endSection() ?>