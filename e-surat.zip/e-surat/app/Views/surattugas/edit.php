<?= $this->extend('layout/default') ?>

<?= $this->section('title') ?>
<title>Halaman | Form Ubah Surat Tugas</title>
<?= $this->endSection() ?>

<?= $this->section('content') ?>
<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <div class="row d-flex justify-content-center">
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Form Ubah Surat Tugas</h6>
            </div>
            <div class="card-body row">
                <div class="text-center">
                    <img class="img-fluid px-3 px-sm-8 mt-3 mb-4" style="width: 25rem;" src="<?= base_url('') ?>/assets/img/undraw_new_entries_re_cffr.svg" alt="...">
                </div>
                <form action="<?= site_url('surattugas/update/' . $surattugas->id_st); ?>" method="post" autocomplete="off">
                    <?= csrf_field() ?>
                    <input type="hidden" name="_method" value="PUT">
                    <div class=" form-group row">
                        <label for="no_surat" class="col-sm-4 col-form-label">Nomor Surat</label>
                        <div class="col-sm-8">
                            <input type="text" class="form-control" name="no_surat" id="no_surat" value="<?= $surat_tugas->no_surat ?>" placeholder="" autofocus required>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="nama" class="col-sm-4 col-form-label">Nama</label>
                        <div class="col-sm-8">
                            <input type="text" class="form-control" name="nama" id="nama" value="<?= $surat_tugas->nama ?>" required>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="Kegiatan" class="col-sm-4 col-form-label">Kegiatan</label>
                        <div class="col-sm-8">
                            <input type="text" class="form-control" name="Kegiatan" id="Kegiatan" value="<?= $surat_tugas->kegiatan ?>" required>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="diselenggarakan_oleh" class="col-sm-4 col-form-label">Diselenggarakan oleh</label>
                        <div class="col-sm-8">
                            <input type="text" class="form-control" name="diselenggarakan_oleh" id="diselenggarakan_oleh" value="<?= $surat_tugas->diselenggarakan_oleh ?>" required>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="tgl_kegiatan" class="col-sm-4 col-form-label">Tanggal Kegiatan</label>
                        <div class="col-sm-8">
                            <input type="date" class="form-control" name="tgl_kegiatan" id="tgl_kegiatan" value="<?= $surat_tugas->tgl_kegiatan ?>" required>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="lokasi" class="col-sm-4 col-form-label">Lokasi</label>
                        <div class="col-sm-8">
                            <input type="text" class="form-control" name="lokasi" id="lokasi" value="<?= $surat_tugas->lokasi ?>" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <button type="button" class="btn btn-secondary nunito;">
                            <i class="fas fa-chevron-circle-left">
                                <a href="<?= site_url('surattugas') ?>" style="font-family: nunito; text-decoration:none; color:white; "> Kembali </a></i>
                        </button>
                        <button type="reset" class="btn btn-danger ml-5 nunito;">
                            <i class="fas fa-trash lg"> Batal</a></i>
                        </button>
                        <button type="submit" class="btn btn-success nunito;">
                            <i class="fas fa-paper-plane">
                                <a href="<?= site_url('surattugas') ?>" style="font-family: nunito; text-decoration:none; color:white; "> Simpan</a></i>
                        </button>
                    </div>
                </form>
            </div>
        </div>
        <!-- </div> -->

    </div>
    <!-- /.container-fluid -->
    <?= $this->endSection() ?>