<?php

namespace App\Models;

use CodeIgniter\Model;

class Modelkaryawan extends Model
{
    protected $table            = 'karyawan';
    protected $primaryKey       = 'id';
    protected $returnType       = 'object';

    // Dates
    protected $useTimestamps = true;
    protected $allowedFields = [
        'id', 'nama', 'jabatan', 'tgl_gabung', 'tgl_lahir', 'nomor_hp'
    ];
}
