<?php

namespace App\Models;

use CodeIgniter\Model;

class Modelpaklaring extends Model
{
    protected $table            = 'surat_ket_kerja';
    protected $primaryKey       = 'id_skk';
    protected $returnType       = 'object';
    protected $allowedFields    = ['no_surat', 'nama', 'dari_tgl', 'sampai_tgl', 'id'];

    protected $useSoftDeletes   = false;

    function getAll()
    {
        $builder = $this->db->table('surat_ket_kerja');
        $builder->join('karyawan', 'karyawan.id = surat_ket_kerja.id_skk');
        $query   = $builder->get();

        return $query->getResult();
    }

    function datapaklaring()
    {
        $this->db->select('*')
            ->from('');
    }
}
