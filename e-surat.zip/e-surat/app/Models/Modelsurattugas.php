<?php

namespace App\Models;

use CodeIgniter\Model;

class Modelsurattugas extends Model
{
    protected $table            = 'surat_tugas';
    protected $primaryKey       = 'id_surat';
    protected $returnType       = 'object';
    protected $allowedFields    = [
        'no_surat', 'nama', 'kegiatan',
        'diselenggarakan_oleh', 'tgl_kegiatan' . 'lokasi'
    ];

    public function getAll()
    {
        $builder = $this->db->table('surat_tugas');
        $builder->join('karyawan', 'karyawan.id = surat_tugas.id_surat');
        $query   = $builder->get();

        return $query->getResult();
    }
}
