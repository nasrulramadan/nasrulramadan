<?php
function userLogin()
{
    $db      = \Config\Database::connect();
    return $db->table('user')->where('id_pengguna', session('id_pengguna'))->get()->getRow();
}
