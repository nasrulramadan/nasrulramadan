$(document).on('click', '#btn-edit', function() {
    $('.modal-body #id_surat_tugas').val($(this).data('id_surat_tugas'));
    $('.modal-body #no_surat').val($(this).data('no_surat'));
    $('.modal-body #nama').val($(this).data('nama'));
    $('.modal-body #Kegiatan').val($(this).data('Kegiatan'));
    $('.modal-body #diselenggarakan_oleh').val($(this).data('diselenggarakan_oleh'));
    $('.modal-body #tgl_kegiatan').val($(this).data('tgl_kegiatan'));
    $('.modal-body #lokasi').val($(this).data('lokasi'));

})